// Questions de culture générale
const quizQuestions = [
    {
        category: "Histoire",
        question: "Qui a été le premier président de la République française ?",
        options: ["Napoléon Bonaparte", "Charles de Gaulle", "François Mitterrand", "Emmanuel Macron"],
        answer: "Charles de Gaulle"
    },
    {
        category: "Géographie",
        question: "Quelle est la capitale de l’Australie ?",
        options: ["Sydney", "Melbourne", "Canberra", "Perth"],
        answer: "Canberra"
    },
    // Ajoutez toutes les autres questions ici...
];

// Questions fun (bonus)
const funQuestions = [
    "Qui ghost le plus souvent ? 👻",
    "Qui est le + à l'Ouest ? 🌍",
    "Qui a le pire sens de l’orientation ? 🗺️",
    // Ajoutez d'autres questions fun...
];

// Variables du jeu
let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 30;
let timer;

// Éléments DOM
const questionElement = document.getElementById("question");
const optionsContainer = document.querySelector(".options");
const scoreElement = document.getElementById("score");
const timeElement = document.getElementById("time");
const nextButton = document.getElementById("next-btn");
const funQuestionElement = document.getElementById("fun-question");
const funOptionsContainer = document.querySelector(".fun-options");
const funQuestionsSection = document.querySelector(".fun-questions");

// Démarrer le quiz
function startQuiz() {
    showQuestion();
    startTimer();
}

// Afficher la question
function showQuestion() {
    const currentQuestion = quizQuestions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    optionsContainer.innerHTML = "";
    currentQuestion.options.forEach(option => {
        const button = document.createElement("button");
        button.textContent = option;
        button.classList.add("option-btn");
        button.addEventListener("click", () => selectAnswer(option));
        optionsContainer.appendChild(button);
    });
}

// Sélectionner une réponse
function selectAnswer(selectedOption) {
    const currentQuestion = quizQuestions[currentQuestionIndex];
    if (selectedOption === currentQuestion.answer) {
        score += 10;
        scoreElement.textContent = score;
        alert("Bonne réponse ! 🎉");
    } else {
        alert(`Mauvaise réponse ! La bonne réponse était : ${currentQuestion.answer} ❌`);
    }
    clearInterval(timer);
    showFunQuestion();
}

// Afficher une question fun
function showFunQuestion() {
    const randomFunQuestion = funQuestions[Math.floor(Math.random() * funQuestions.length)];
    funQuestionElement.textContent = randomFunQuestion;
    funQuestionsSection.classList.remove("hidden");
    // Générer des options fun (noms des participants)
    funOptionsContainer.innerHTML = "";
    const players = ["Alice", "Bob", "Charlie", "Diana"]; // Remplacer par les vrais joueurs
    players.forEach(player => {
        const button = document.createElement("button");
        button.textContent = player;
        button.classList.add("option-btn");
        button.addEventListener("click", () => {
            alert(`${player} a été choisi(e) ! 😂`);
            nextQuestion();
        });
        funOptionsContainer.appendChild(button);
    });
}

// Passer à la question suivante
function nextQuestion() {
    funQuestionsSection.classList.add("hidden");
    currentQuestionIndex++;
    if (currentQuestionIndex < quizQuestions.length) {
        showQuestion();
        resetTimer();
    } else {
        endQuiz();
    }
}

// Timer
function startTimer() {
    timer = setInterval(() => {
        timeLeft--;
        timeElement.textContent = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(timer);
            alert("Temps écoulé ! ⏰");
            showFunQuestion();
        }
    }, 1000);
}

function resetTimer() {
    timeLeft = 30;
    timeElement.textContent = timeLeft;
    startTimer();
}

// Fin du quiz
function endQuiz() {
    questionElement.textContent = `Quiz terminé ! Ton score final est : ${score} 🏆`;
    optionsContainer.innerHTML = "";
    nextButton.style.display = "none";
}

// Événements
nextButton.addEventListener("click", nextQuestion);

// Démarrer le jeu
startQuiz();