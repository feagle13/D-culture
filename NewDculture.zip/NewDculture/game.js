// Connexion WebSocket
const socket = io();

// Éléments DOM
const quizScreen = document.querySelector(".quiz-screen");
const voteScreen = document.querySelector(".vote-screen");
const leaderboardScreen = document.querySelector(".leaderboard-screen");
const questionText = document.getElementById("question-text");
const optionsGrid = document.querySelector(".options-grid");
const voteOptions = document.querySelector(".vote-options");

// Variables du jeu
let currentQuestion = {};
let selectedAnswer = "";
let players = [];

// Reçoit une nouvelle question du serveur
socket.on("new-question", (question) => {
    currentQuestion = question;
    displayQuestion(question);
});

// Affiche la question
function displayQuestion(question) {
    quizScreen.classList.remove("hidden");
    voteScreen.classList.add("hidden");
    questionText.textContent = question.text;
    optionsGrid.innerHTML = "";

    question.options.forEach((option, index) => {
        const button = document.createElement("button");
        button.textContent = option;
        button.addEventListener("click", () => selectAnswer(option));
        optionsGrid.appendChild(button);
    });
}

// Sélectionne une réponse
function selectAnswer(answer) {
    selectedAnswer = answer;
    socket.emit("submit-answer", answer);
    quizScreen.classList.add("hidden");
    voteScreen.classList.remove("hidden");
    startVoteTimer();
}

// Système de vote
function startVoteTimer() {
    let timeLeft = 45;
    const voteTimer = setInterval(() => {
        timeLeft--;
        document.getElementById("vote-time").textContent = timeLeft;
        if (timeLeft <= 0) {
            clearInterval(voteTimer);
            socket.emit("end-voting");
        }
    }, 1000);
}

// Affiche le classement final
socket.on("game-over", (leaderboard) => {
    leaderboardScreen.classList.remove("hidden");
    const leaderboardElement = document.querySelector(".leaderboard");
    leaderboardElement.innerHTML = "";

    leaderboard.forEach((player, index) => {
        const playerElement = document.createElement("div");
        playerElement.classList.add("player");
        playerElement.innerHTML = `
            <span class="rank">${index + 1}</span>
            <span class="name">${player.name}</span>
            <span class="score">${player.score} pts</span>
        `;
        leaderboardElement.appendChild(playerElement);
    });
});