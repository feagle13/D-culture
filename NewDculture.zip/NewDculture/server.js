const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Données du jeu
const rooms = {};
const quizQuestions = require("./questions.json"); // Importez vos questions

io.on("connection", (socket) => {
    // Créer une nouvelle partie
    socket.on("create-room", (username, questionCount) => {
        const roomId = generateRoomCode();
        rooms[roomId] = {
            players: [{ id: socket.id, name: username, score: 0 }],
            questions: quizQuestions.slice(0, questionCount),
            currentQuestionIndex: 0,
            votes: {}
        };
        socket.join(roomId);
        socket.emit("room-created", roomId);
    });

    // Rejoindre une partie
    socket.on("join-room", (roomId, username) => {
        if (rooms[roomId]) {
            rooms[roomId].players.push({ id: socket.id, name: username, score: 0 });
            socket.join(roomId);
            io.to(roomId).emit("player-joined", rooms[roomId].players);
        } else {
            socket.emit("invalid-room");
        }
    });

    // Lancer la partie
    socket.on("start-game", (roomId) => {
        const room = rooms[roomId];
        if (room) {
            sendQuestion(roomId, 0);
        }
    });

    // Envoyer une question
    function sendQuestion(roomId, index) {
        const room = rooms[roomId];
        if (index < room.questions.length) {
            io.to(roomId).emit("new-question", room.questions[index]);
        } else {
            endGame(roomId);
        }
    }

    // Fin du jeu
    function endGame(roomId) {
        const room = rooms[roomId];
        const leaderboard = room.players.sort((a, b) => b.score - a.score);
        io.to(roomId).emit("game-over", leaderboard);
        delete rooms[roomId];
    }
});

// Générer un code de salon aléatoire
function generateRoomCode() {
    return Math.random().toString(36).substring(2, 6).toUpperCase();
}

server.listen(3000, () => console.log("Server running on port 3000"));